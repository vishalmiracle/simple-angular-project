import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { timeout, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class GetuserService {
  httpOptions = {
    headers: new HttpHeaders({
    })
  };
  timeout_message = "Time Out";
  timeout_delay = 30000;
  constructor(private http: HttpClient) {
    this.httpOptions.headers = this.httpOptions.headers.append('accept', 'application/json');
   }

   getUserList(parameter): Observable<any> {
    console.log("In writetag() service ", parameter);
  
    return this.http.get("https://jsonplaceholder.typicode.com/users", this.httpOptions).pipe(timeout(this.timeout_delay))
  }

}
