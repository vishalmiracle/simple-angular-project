import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WrapperinputComponent } from './components/wrapperinput/wrapperinput.component';
import { MaincomponentComponent } from './components/maincomponent/maincomponent.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { MatButtonModule, MatCardModule, MatCheckboxModule, MatOptionModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MatTableModule, MatToolbarModule, MatDialogModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { DialogComponent } from './components/dialog/dialog.component';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { MatSnackBarModule } from "@angular/material";
@NgModule({
  declarations: [
    AppComponent,
    WrapperinputComponent,
    MaincomponentComponent,
    DialogComponent,SpinnerComponent
    
  ],
  imports: [BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule, FormsModule, ReactiveFormsModule ,MatFormFieldModule,
    MatInputModule,
    BrowserModule,
    MatTableModule,
    MatSortModule,
    BrowserModule,
    AppRoutingModule,
    MatCardModule,
    MatToolbarModule,
    MatButtonModule,
    MatSnackBarModule,
 
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule, MatOptionModule,
    MatCheckboxModule, MatSelectModule,
    // MatIconModule, MatRadioModule,
    // MatDatepickerModule,
    // MatNativeDateModule,
    // MatExpansionModule,
    MatDialogModule,


    MatSortModule,

  ],
  entryComponents: [DialogComponent],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
