import { Component, OnInit, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: 'app-maincomponent',
  templateUrl: './maincomponent.component.html',
  styleUrls: ['./maincomponent.component.css']
})
export class MaincomponentComponent implements OnInit, OnChanges {

  customInputForm: FormGroup;
  @Input() action: any;
  @Input() userObject: any;
  @Output() backEvent = new EventEmitter<any>();
  constructor(private formBuilder: FormBuilder, private snackBar: MatSnackBar) {
    this.customInputForm = this.formBuilder.group(

      {
        "id": null,
        "name": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
        "username": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
        "email": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
        "address": this.formBuilder.group({
          "street": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
          "suite": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
          "city": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
          "zipcode": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
          "geo": this.formBuilder.group({
            "lat": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
            "lng": ["", [Validators.required, UsernameValidator.cannotContainSpace]]
          })
        }),
        "phone": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
        "website": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
        "company": this.formBuilder.group({
          "name": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
          "catchPhrase": ["", [Validators.required, UsernameValidator.cannotContainSpace]],
          "bs": ["", [Validators.required, UsernameValidator.cannotContainSpace]]
        })
      }
      // // Uncomment to test `registerOnTouched`
      // // { validator: { updateOn: 'blur' } }
    );
  }
  ngOnChanges(change: SimpleChanges) {
    console.log(change);
    if (change.userObject != undefined) {
      if (change.userObject.currentValue != undefined) {
        this.customInputForm = this.formBuilder.group(

          {
            "id": null,
            "name": [this.userObject.name, [Validators.required, UsernameValidator.cannotContainSpace]],
            "username": [this.userObject.username, [Validators.required, UsernameValidator.cannotContainSpace]],
            "email": [this.userObject.email, [Validators.required, UsernameValidator.cannotContainSpace]],
            "address": this.formBuilder.group({
              "street": [this.userObject.address.street, [Validators.required, UsernameValidator.cannotContainSpace]],
              "suite": [this.userObject.address.suite, [Validators.required, UsernameValidator.cannotContainSpace]],
              "city": [this.userObject.address.city, [Validators.required, UsernameValidator.cannotContainSpace]],
              "zipcode": [this.userObject.address.zipcode, [Validators.required, UsernameValidator.cannotContainSpace]],
              "geo": this.formBuilder.group({
                "lat": [this.userObject.address.geo.lat, [Validators.required, UsernameValidator.cannotContainSpace]],
                "lng": [this.userObject.address.geo.lng, [Validators.required, UsernameValidator.cannotContainSpace]]
              })
            }),
            "phone": [this.userObject.phone, [Validators.required, UsernameValidator.cannotContainSpace]],
            "website": [this.userObject.website, [Validators.required, UsernameValidator.cannotContainSpace]],
            "company": this.formBuilder.group({
              "name": [this.userObject.company.name, [Validators.required, UsernameValidator.cannotContainSpace]],
              "catchPhrase": [this.userObject.company.catchPhrase, [Validators.required, UsernameValidator.cannotContainSpace]],
              "bs": [this.userObject.company.bs, [Validators.required, UsernameValidator.cannotContainSpace]]
            })
          }
          // // Uncomment to test `registerOnTouched`
          // // { validator: { updateOn: 'blur' } }
        );
      }
    }

  }
  ngOnInit() {
    // if (this.userObject != null || this.userObject != null) {

    // }



  }
  get validatorDummy() {
    console.log("form", this.customInputForm.controls.name);
    return true;
  }
  getErrorMessage(error) {
    if (this.f[error + ""].errors != undefined || this.f[error + ""].errors != null) {
      // console.log("form", error, this.f[error + ""].errors);
      if (this.f[error + ""].errors.required != undefined || this.f[error + ""].errors.required != null) {
        // console.log(error, " vishal");

      }
      else {
        console.log(error, "");
      }
    }


    // return true;
  }
  get f() {
    return this.customInputForm.controls;
  }
  get dummy() {
    console.log();
    return null

  }

  clear() {
    // await this.delay(10);
    this.customInputForm.reset();
    Object.keys(this.customInputForm.controls).forEach(key => {
      this.customInputForm.controls[key].setErrors(null)
    });

    this.customInputForm.setErrors({ 'incorrect': true })
  }
  back() {
    this.backEvent.emit("")
  }
  submitForm() {
    if (this.action == "create") {
      this.openSnackBar("Form submitted but you have not provided api to create employee", "Success")
      this.clear()
    }
    else if (this.action == "edit") {
      this.openSnackBar("Form edited and submitted but you have not provided api to create employee", "Success")
      this.clear()
    }
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 3000,
    });

  }
}


import { AbstractControl, ValidationErrors } from '@angular/forms';
import { MatDialog, MatSnackBar } from '@angular/material';
import { DialogComponent } from '../dialog/dialog.component';

export class UsernameValidator {
  static cannotContainSpace(control: AbstractControl): ValidationErrors | null {
    if (control && (control.value != null || control.value != undefined))
      if ((control.value as string).charAt(0) == " ") {
        return { cannotContainSpace: true }
      }
      else {
        return null
      }
    else return null

  }
}