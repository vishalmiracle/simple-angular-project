import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WrapperinputComponent } from './wrapperinput.component';

describe('WrapperinputComponent', () => {
  let component: WrapperinputComponent;
  let fixture: ComponentFixture<WrapperinputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WrapperinputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WrapperinputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
