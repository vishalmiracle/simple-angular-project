import { Component } from '@angular/core';
import { GetuserService } from './getuser.service';
import { DialogComponent } from './components/dialog/dialog.component';
import { MatDialog, MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'simpletask';
  userArray: any = [];
  selectedAction: string = ""
  subaction: string = ""
  selectedObject: any = {}
  animal: string;
  name: string;
  overlay: boolean = false;
  constructor(private service: GetuserService, public dialog: MatDialog, public snackBar: MatSnackBar) {

  }

  getUserList() {
    this.overlay = true;
    this.service.getUserList({}).subscribe(res => {
      console.log(res);
      this.userArray = res;
      this.overlay = false;
      this.openSnackBar("User list fetched successfully", "Success")
    },
      error => {
        console.log(error);
        this.overlay = false;
        this.openSnackBar("Please refresh or try again later", "Error")

      })
  }
  editUser(element, i) {
    if (this.selectedAction == "edit") {
      this.subaction = "selected";
      this.selectedObject = element
    }
    else if (this.selectedAction == "delete") {
      this.subaction = "deleteSelected";
      this.selectedObject = element;
      this.openDialog(i)
    }

    console.log(element);

  }
  backPressed($event) {
    console.log("backpresed", $event);
    if (this.selectedAction == "edit") {
      this.subaction = "";
      this.selectedObject = null;
    }
    else if (this.selectedAction == "create") {
      this.subaction = "";
      this.selectedAction = ""
      // this.selectedObject="";
    }

  }

  openDialog(index): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '250px',
      data: { name: this.selectedObject.name, animal: this.animal }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.userArray.splice(index, 1);
        this.openSnackBar("Temporary deleted from list because you have not provided end point for it","Success")
      }
      else{
        this.openSnackBar("You cancelled the operation","Avoided")

      }

      console.log('The dialog was closed', result);

    });
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 3000,
    });

  }
}
